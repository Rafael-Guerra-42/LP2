namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || !Double.TryParse(txtAltura.Text, out altura) || raio <= 0 || altura <= 0)
            {
                MessageBox.Show("Numeros Invalidos");
                txtRaio.Focus();
            }
            else
            {
                resultado = Math.PI * Math.Pow(raio, 2) * altura;
                txtResultado.Text = resultado.ToString("N2");



            }
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("raio invalido");
                // txtRaio.Focus();

            }
            else if (raio <= 0)
            {
                MessageBox.Show("raio deve ser maior que zero");
                //  txtRaio.Focus();

            }

        }

        private void txtAltura_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("altura invalida");
                // e.Cancel = true;
            }
            else if (altura <= 0)
            {
                MessageBox.Show("altura deve ser maior que zero");
                //e.Cancel = true;
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

            txtAltura.Clear();
            txtResultado.Text = string.Empty;
            txtRaio.Text = "";

        }
    }
}
