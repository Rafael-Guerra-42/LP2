﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblValorA = new Label();
            lblValorB = new Label();
            lblValorC = new Label();
            txtValorA = new TextBox();
            txtValorB = new TextBox();
            txtValorC = new TextBox();
            btnExecuta = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblValorA
            // 
            lblValorA.AutoSize = true;
            lblValorA.Location = new Point(134, 44);
            lblValorA.Name = "lblValorA";
            lblValorA.Size = new Size(94, 25);
            lblValorA.TabIndex = 0;
            lblValorA.Text = "Valor de A";
            lblValorA.Click += label1_Click;
            // 
            // lblValorB
            // 
            lblValorB.AutoSize = true;
            lblValorB.Location = new Point(134, 125);
            lblValorB.Name = "lblValorB";
            lblValorB.Size = new Size(92, 25);
            lblValorB.TabIndex = 1;
            lblValorB.Text = "Valor de B";
            lblValorB.Click += label2_Click;
            // 
            // lblValorC
            // 
            lblValorC.AutoSize = true;
            lblValorC.Location = new Point(134, 213);
            lblValorC.Name = "lblValorC";
            lblValorC.Size = new Size(93, 25);
            lblValorC.TabIndex = 2;
            lblValorC.Text = "Valor de C";
            // 
            // txtValorA
            // 
            txtValorA.Location = new Point(324, 38);
            txtValorA.Name = "txtValorA";
            txtValorA.Size = new Size(150, 31);
            txtValorA.TabIndex = 3;
            txtValorA.Validating += txtValorA_Validating;
            // 
            // txtValorB
            // 
            txtValorB.Location = new Point(324, 125);
            txtValorB.Name = "txtValorB";
            txtValorB.Size = new Size(150, 31);
            txtValorB.TabIndex = 4;
            txtValorB.Validating += txtValorB_Validating;
            // 
            // txtValorC
            // 
            txtValorC.Location = new Point(324, 213);
            txtValorC.Name = "txtValorC";
            txtValorC.Size = new Size(150, 31);
            txtValorC.TabIndex = 5;
            txtValorC.Validating += txtValorC_Validating;
            // 
            // btnExecuta
            // 
            btnExecuta.Location = new Point(106, 308);
            btnExecuta.Name = "btnExecuta";
            btnExecuta.Size = new Size(112, 34);
            btnExecuta.TabIndex = 6;
            btnExecuta.Text = "Executa";
            btnExecuta.UseVisualStyleBackColor = true;
            btnExecuta.Click += btnExecuta_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(336, 308);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1040, 621);
            Controls.Add(btnSair);
            Controls.Add(btnExecuta);
            Controls.Add(txtValorC);
            Controls.Add(txtValorB);
            Controls.Add(txtValorA);
            Controls.Add(lblValorC);
            Controls.Add(lblValorB);
            Controls.Add(lblValorA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblValorA;
        private Label lblValorB;
        private Label lblValorC;
        private TextBox txtValorA;
        private TextBox txtValorB;
        private TextBox txtValorC;
        private Button btnExecuta;
        private Button btnSair;
    }
}
