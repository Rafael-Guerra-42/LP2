namespace PTriangulo
{
    public partial class Form1 : Form
    {

        double valA, valB, valC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtValorA_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out valA))
            {
                MessageBox.Show("Digite um valor valido para A");
                e.Cancel = true;

            }
        }

        private void txtValorB_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out valB))
            {
                MessageBox.Show("Digite um valor valido para B");
                e.Cancel = true;
            }
        }

        private void txtValorC_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out valC))
            {
                MessageBox.Show("Digite um valor valido para B");
                e.Cancel = true;

            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (!(valA < valB + valC && valA > Math.Abs(valB - valC)
             && valB < valA + valC && valB > Math.Abs(valA - valC)
             && valC < valA + valB && valC > Math.Abs(valA - valB)))
            {
                MessageBox.Show("Nao existe um triangulo com essas medidas de lados");
                txtValorA.Focus();


            }
            else
            {
                if(valA==valB  && valB==valC)
                {
                    MessageBox.Show("E um triangulo equilatero");
                }else if ((valA==valB && valA !=valC) || (valA==valC && valA !=valB) ||(valB == valC && valB != valA))
                {
                    MessageBox.Show("E um triangulo isoceles");
                }else if (valA != valB && valB != valC)
                {
                    MessageBox.Show("E um triangulo escaleno");

                }
            }
        }
    }
}
