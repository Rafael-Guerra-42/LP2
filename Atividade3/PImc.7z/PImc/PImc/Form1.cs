﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("digite um valor valido para altura");
                e.Cancel = true;
            }
        }
        
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (peso <= 0 || altura <= 0)
            {
                MessageBox.Show("Corrija os valores, altura e peso devem ser maiores do que zero");
                mskbxPeso.Focus();
            }
            else
            {
                imc = peso/Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                txtImc.Text = Convert.ToString(imc);
                if (imc < 18.5)
                    MessageBox.Show("Nível Magreza");
                else if (imc < 24.9)
                    MessageBox.Show("Nível Normal");
                else if (imc < 29.9)
                    MessageBox.Show("Nível Sobrepeso (Grau 1)");
                else if (imc < 39.9)
                    MessageBox.Show("Nível Obesidade (Grau 2)");
                else
                    MessageBox.Show("Nível Obesidade Grave (Grau 3)");

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("digite um valor valido para peso");
                e.Cancel = true;
            }

            //MessageBox.Show(Convert.ToString(peso));
        }
    }
}
