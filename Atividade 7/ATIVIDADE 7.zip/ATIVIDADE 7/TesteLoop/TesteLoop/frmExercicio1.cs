﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TesteLoop
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnParletra_Click(object sender, EventArgs e)
        {
            int n = 0;
            for (int cont=0; cont < rchTexto.Text.Length; cont++)
            {
                if (char.IsWhiteSpace(rchTexto.Text[cont]))
                    cont++;
                else if (cont < rchTexto.Text.Length-1 && rchTexto.Text[cont] == rchTexto.Text[cont + 1])
                    n++;
            }
            txtResposta.Text = n.ToString();
        }

        private void BtnQtdEspaco_Click(object sender, EventArgs e)
        {
            int n=0;
            for(int cont=0;cont<rchTexto.Text.Length;cont++)
            {
                if (char.IsWhiteSpace(rchTexto.Text, cont))
                    n++;
            }
            txtResposta.Text = n.ToString();
        }

        private void BtnQtdR_Click(object sender, EventArgs e)
        { int n = 0;
            foreach (char x in rchTexto.Text.ToUpper())
                if (x == 'R')
                    n++;
            txtResposta.Text = n.ToString();
        }
    }
}
