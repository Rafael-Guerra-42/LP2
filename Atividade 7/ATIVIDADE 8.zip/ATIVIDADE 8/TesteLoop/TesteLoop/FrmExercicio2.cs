﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TesteLoop
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            int num;
            double resultado=0;
            if (!int.TryParse(txtNum.Text, out num))
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                for (double cont = 1; cont <= num; cont++)
                {
                    
                    resultado = resultado+(1/cont);
                }
            }
            txtResposta.Text = resultado.ToString("N2");
        }
    }
}
