﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace PContato0030482423007
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=LAPTOP-MLONG046\\SQLEXPRESS;Initial Catalog=LP2;Integrated Security=True;Pooling=False;");
                conexao.Open();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir banco de dados "+ex.Message);
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Form fc = Application.OpenForms["frmContato"];
            if (fc != null)
                fc.Close();

            frmContato FRMC = new frmContato();
            FRMC.MdiParent = this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form  fcSobre = Application.OpenForms["frmSobre"];
            if (fcSobre != null)
                fcSobre.Close();

            frmSobre objFrmSobre = new frmSobre();
            objFrmSobre.MdiParent = this;
            objFrmSobre.WindowState = FormWindowState.Maximized;
            objFrmSobre.Show();
        }
    }
}
